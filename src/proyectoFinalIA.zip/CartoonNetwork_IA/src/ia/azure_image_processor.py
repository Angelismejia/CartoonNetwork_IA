import os
import json
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
import io
from datetime import datetime
from PIL import Image, ImageTk
import pyodbc
from azure.storage.blob import BlobServiceClient
from azure.cognitiveservices.vision.customvision.prediction import CustomVisionPredictionClient
from msrest.authentication import ApiKeyCredentials
# Import the personajes dictionary
from personaje import personajes

class RedirectText:
    """Clase para redirigir la salida de print a un widget de texto"""
    def __init__(self, text_widget):
        self.text_widget = text_widget
        self.buffer = ""

    def write(self, string):
        self.buffer += string
        self.text_widget.configure(state="normal")
        self.text_widget.insert(tk.END, string)
        self.text_widget.see(tk.END)
        self.text_widget.configure(state="disabled")
    
    def flush(self):
        pass

class CartoonNetworkApp:
    def __init__(self, root, config_file):
        self.root = root
        self.root.title("Cartoon Network - Procesador de Imágenes")
        self.root.geometry("1000x700")
        self.root.minsize(800, 600)
        
        # Cargar configuración
        try:
            with open(config_file, 'r') as f:
                self.config = json.load(f)
            self.config_file = config_file
            
            # Imprimir información de configuración para depuración
            print("Configuración cargada:")
            print(f"- Blob Storage Container: {self.config['AzureBlobStorage']['ContainerName']}")
            print(f"- Custom Vision Project ID: {self.config['CustomVision']['ProjectId']}")
            print(f"- Custom Vision Model: {self.config['CustomVision']['PublishedModelName']}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al cargar la configuración: {str(e)}")
            root.destroy()
            return
        
        # Variables
        self.selected_folder = tk.StringVar()
        self.status_var = tk.StringVar(value="Listo para procesar imágenes")
        self.progress_var = tk.DoubleVar(value=0)
        self.images_list = []
        self.results = []
        
        # Crear interfaz
        self.create_widgets()
        
        # Inicializar servicios de Azure
        self.initialize_azure_services()
    
    def create_widgets(self):
        # Frame principal con pestañas
        self.tab_control = ttk.Notebook(self.root)
        
        # Pestaña de procesamiento
        self.process_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.process_tab, text="Procesar Imágenes")
        
        # Pestaña de resultados
        self.results_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.results_tab, text="Ver Resultados")
        
        # Pestaña de configuración
        self.config_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.config_tab, text="Configuración")
        
        self.tab_control.pack(expand=1, fill="both")
        
        # Configurar pestaña de procesamiento
        self.setup_process_tab()
        
        # Configurar pestaña de resultados
        self.setup_results_tab()
        
        # Configurar pestaña de configuración
        self.setup_config_tab()
        
        # Barra de estado
        status_frame = ttk.Frame(self.root)
        status_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Label(status_frame, textvariable=self.status_var).pack(side="left")
        
        # Barra de progreso
        self.progress = ttk.Progressbar(
            status_frame, 
            orient="horizontal", 
            length=200, 
            mode="determinate",
            variable=self.progress_var
        )
        self.progress.pack(side="right", padx=5)
    
    def setup_process_tab(self):
        # Frame superior para selección de carpeta
        folder_frame = ttk.LabelFrame(self.process_tab, text="Selección de Carpeta")
        folder_frame.pack(fill="x", padx=10, pady=10)
        
        ttk.Entry(folder_frame, textvariable=self.selected_folder, width=70).pack(side="left", padx=5, pady=5, expand=True, fill="x")
        ttk.Button(folder_frame, text="Examinar...", command=self.browse_folder).pack(side="left", padx=5, pady=5)
        
        # Frame central con dos columnas
        main_frame = ttk.Frame(self.process_tab)
        main_frame.pack(expand=True, fill="both", padx=10, pady=5)
        
        # Columna izquierda: Lista de imágenes
        left_frame = ttk.LabelFrame(main_frame, text="Imágenes Seleccionadas")
        left_frame.pack(side="left", expand=True, fill="both", padx=5, pady=5)
        
        # Lista de imágenes con scrollbar
        list_frame = ttk.Frame(left_frame)
        list_frame.pack(expand=True, fill="both", padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.images_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, selectmode="extended")
        self.images_listbox.pack(expand=True, fill="both")
        scrollbar.config(command=self.images_listbox.yview)
        
        # Botones para la lista
        buttons_frame = ttk.Frame(left_frame)
        buttons_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Button(buttons_frame, text="Actualizar Lista", command=self.refresh_images_list).pack(side="left", padx=5)
        ttk.Button(buttons_frame, text="Limpiar Selección", command=self.clear_selection).pack(side="left", padx=5)
        
        # Columna derecha: Consola de log y botones de acción
        right_frame = ttk.LabelFrame(main_frame, text="Registro de Actividad")
        right_frame.pack(side="right", expand=True, fill="both", padx=5, pady=5)
        
        # Área de texto para log
        self.log_text = ScrolledText(right_frame, state="disabled", wrap=tk.WORD, height=15)
        self.log_text.pack(expand=True, fill="both", padx=5, pady=5)
        
        # Redirigir stdout al widget de texto
        self.stdout_redirect = RedirectText(self.log_text)
        sys.stdout = self.stdout_redirect
        
        # Botones de acción
        action_frame = ttk.Frame(right_frame)
        action_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Button(
            action_frame, 
            text="Procesar Imágenes", 
            command=self.process_images_thread,
            style="Accent.TButton"
        ).pack(side="right", padx=5)
        
        ttk.Button(
            action_frame, 
            text="Limpiar Log", 
            command=self.clear_log
        ).pack(side="right", padx=5)
    
    def setup_results_tab(self):
        # Frame superior con botones
        control_frame = ttk.Frame(self.results_tab)
        control_frame.pack(fill="x", padx=10, pady=10)
        
        ttk.Button(
            control_frame, 
            text="Consultar Resultados Recientes", 
            command=self.query_results_thread
        ).pack(side="left", padx=5)
        
        ttk.Label(control_frame, text="Límite:").pack(side="left", padx=5)
        self.limit_var = tk.StringVar(value="20")
        ttk.Spinbox(
            control_frame, 
            from_=1, 
            to=100, 
            textvariable=self.limit_var, 
            width=5
        ).pack(side="left")
        
        # Tabla de resultados
        results_frame = ttk.LabelFrame(self.results_tab, text="Resultados del Análisis")
        results_frame.pack(expand=True, fill="both", padx=10, pady=5)
        
        # Crear Treeview para mostrar resultados
        columns = ("id", "filename", "blob_name", "tag", "confidence", "date")
        self.results_tree = ttk.Treeview(results_frame, columns=columns, show="headings")
        
        # Definir encabezados
        self.results_tree.heading("id", text="ID")
        self.results_tree.heading("filename", text="Archivo Original")
        self.results_tree.heading("blob_name", text="Nombre en Blob")
        self.results_tree.heading("tag", text="Etiqueta Principal")
        self.results_tree.heading("confidence", text="Confianza")
        self.results_tree.heading("date", text="Fecha de Análisis")
        
        # Configurar anchos de columna
        self.results_tree.column("id", width=50)
        self.results_tree.column("filename", width=150)
        self.results_tree.column("blob_name", width=200)
        self.results_tree.column("tag", width=150)
        self.results_tree.column("confidence", width=100)
        self.results_tree.column("date", width=150)
        
        # Scrollbars
        vsb = ttk.Scrollbar(results_frame, orient="vertical", command=self.results_tree.yview)
        hsb = ttk.Scrollbar(results_frame, orient="horizontal", command=self.results_tree.xview)
        self.results_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Empaquetar todo
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        self.results_tree.pack(expand=True, fill="both")
        
        # Evento de doble clic para ver detalles
        self.results_tree.bind("<Double-1>", self.show_result_details)
    
    def setup_config_tab(self):
        """Configurar pestaña para editar la configuración"""
        config_frame = ttk.Frame(self.config_tab)
        config_frame.pack(expand=True, fill="both", padx=10, pady=10)
        
        # Sección de Azure Blob Storage
        blob_frame = ttk.LabelFrame(config_frame, text="Azure Blob Storage")
        blob_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Label(blob_frame, text="Container Name:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.container_name_var = tk.StringVar(value=self.config["AzureBlobStorage"]["ContainerName"])
        ttk.Entry(blob_frame, textvariable=self.container_name_var, width=40).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        
        # Sección de Azure Custom Vision
        vision_frame = ttk.LabelFrame(config_frame, text="Azure Custom Vision")
        vision_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Label(vision_frame, text="Prediction Key:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.prediction_key_var = tk.StringVar(value=self.config["CustomVision"]["PredictionKey"])
        ttk.Entry(vision_frame, textvariable=self.prediction_key_var, width=40).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(vision_frame, text="Endpoint:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.endpoint_var = tk.StringVar(value=self.config["CustomVision"]["Endpoint"])
        ttk.Entry(vision_frame, textvariable=self.endpoint_var, width=40).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(vision_frame, text="Project ID:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.project_id_var = tk.StringVar(value=self.config["CustomVision"]["ProjectId"])
        ttk.Entry(vision_frame, textvariable=self.project_id_var, width=40).grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(vision_frame, text="Published Model Name:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.model_name_var = tk.StringVar(value=self.config["CustomVision"]["PublishedModelName"])
        ttk.Entry(vision_frame, textvariable=self.model_name_var, width=40).grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(vision_frame, text="Confidence Threshold:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.threshold_var = tk.StringVar(value=self.config["CustomVision"]["ConfidenceThreshold"])
        ttk.Entry(vision_frame, textvariable=self.threshold_var, width=40).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        
        # Sección de SQL Connection
        sql_frame = ttk.LabelFrame(config_frame, text="SQL Connection")
        sql_frame.pack(fill="x", padx=5, pady=5)
        
        ttk.Label(sql_frame, text="Server:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.sql_server_var = tk.StringVar(value="tcp:cartoonnetworkserver.database.windows.net")
        ttk.Entry(sql_frame, textvariable=self.sql_server_var, width=40).grid(row=0, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(sql_frame, text="Database:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.sql_database_var = tk.StringVar(value="cartoonnetwork_db")
        ttk.Entry(sql_frame, textvariable=self.sql_database_var, width=40).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(sql_frame, text="Username:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.sql_username_var = tk.StringVar(value="servidor")
        ttk.Entry(sql_frame, textvariable=self.sql_username_var, width=40).grid(row=2, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(sql_frame, text="Password:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.sql_password_var = tk.StringVar(value="Candy#1665")
        ttk.Entry(sql_frame, textvariable=self.sql_password_var, width=40, show="*").grid(row=3, column=1, sticky="ew", padx=5, pady=5)
        
        ttk.Label(sql_frame, text="Driver:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.sql_driver_var = tk.StringVar(value="ODBC Driver 18 for SQL Server")
        ttk.Entry(sql_frame, textvariable=self.sql_driver_var, width=40).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
        
        # Botones
        buttons_frame = ttk.Frame(config_frame)
        buttons_frame.pack(fill="x", padx=5, pady=10)
        
        ttk.Button(
            buttons_frame, 
            text="Guardar Cambios", 
            command=self.save_config
        ).pack(side="right", padx=5)
        
        ttk.Button(
            buttons_frame, 
            text="Probar Conexión", 
            command=self.test_connections
        ).pack(side="right", padx=5)
    
    def save_config(self):
        """Guardar cambios en la configuración"""
        try:
            # Actualizar valores en el objeto de configuración
            self.config["AzureBlobStorage"]["ContainerName"] = self.container_name_var.get()
            self.config["CustomVision"]["PredictionKey"] = self.prediction_key_var.get()
            self.config["CustomVision"]["Endpoint"] = self.endpoint_var.get()
            self.config["CustomVision"]["ProjectId"] = self.project_id_var.get()
            self.config["CustomVision"]["PublishedModelName"] = self.model_name_var.get()
            self.config["CustomVision"]["ConfidenceThreshold"] = self.threshold_var.get()
            
            # Actualizar la cadena de conexión SQL
            server = self.sql_server_var.get()
            database = self.sql_database_var.get()
            username = self.sql_username_var.get()
            password = self.sql_password_var.get()
            driver = self.sql_driver_var.get()
            
            # Construir la cadena de conexión
            sql_connection_string = f"Driver={{{driver}}};Server={server};Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;"
            
            # Actualizar en el objeto de configuración
            if "ConnectionStrings" not in self.config:
                self.config["ConnectionStrings"] = {}
            self.config["ConnectionStrings"]["CartoonNetwork_IAContext"] = sql_connection_string
            
            # Guardar en archivo
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            
            # Reinicializar servicios
            self.initialize_azure_services()
            
            messagebox.showinfo("Configuración", "Configuración guardada correctamente.")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar la configuración: {str(e)}")
    
    def test_connections(self):
        """Probar conexiones a los servicios de Azure"""
        results = []
        
        # Probar Blob Storage
        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            container_client.get_container_properties()
            results.append(("Azure Blob Storage", "Conexión exitosa"))
        except Exception as e:
            results.append(("Azure Blob Storage", f"Error: {str(e)}"))
        
        # Probar Custom Vision
        try:
            # Intentar una predicción simple con una imagen de prueba
            # Crear una imagen de prueba en memoria
            from PIL import Image, ImageDraw
            img = Image.new('RGB', (100, 100), color = (73, 109, 137))
            d = ImageDraw.Draw(img)
            d.text((10,10), "Test", fill=(255,255,0))
            
            # Guardar en un buffer
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format='PNG')
            img_byte_arr = img_byte_arr.getvalue()
            
            # Intentar predecir
            self.prediction_client.classify_image(
                self.project_id,
                self.published_model_name,
                img_byte_arr
            )
            
            results.append(("Azure Custom Vision", "Conexión exitosa"))
        except Exception as e:
            results.append(("Azure Custom Vision", f"Error: {str(e)}"))
        
        # Probar SQL Database
        try:
            # Construir la cadena de conexión con los valores actuales
            server = self.sql_server_var.get()
            database = self.sql_database_var.get()
            username = self.sql_username_var.get()
            password = self.sql_password_var.get()
            driver = self.sql_driver_var.get()
            
            # Construir la cadena de conexión
            conn_string = f"Driver={{{driver}}};Server={server};Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;"
            
            # Intentar conectar
            print(f"Probando conexión SQL con: {conn_string}")
            conn = pyodbc.connect(conn_string)
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            conn.close()
            results.append(("Azure SQL Database", "Conexión exitosa"))
        except Exception as e:
            results.append(("Azure SQL Database", f"Error: {str(e)}"))
        
        # Mostrar resultados
        result_text = "\n".join([f"{service}: {status}" for service, status in results])
        messagebox.showinfo("Resultados de Prueba", result_text)
    
    def initialize_azure_services(self):
        try:
            # Inicializar Azure Blob Storage
            self.blob_connection_string = self.config["AzureBlobStorage"]["ConnectionString"]
            self.container_name = self.config["AzureBlobStorage"]["ContainerName"]
            self.blob_service_client = BlobServiceClient.from_connection_string(self.blob_connection_string)
            
            # Inicializar Azure Custom Vision
            self.prediction_key = self.config["CustomVision"]["PredictionKey"]
            self.prediction_endpoint = self.config["CustomVision"]["Endpoint"]
            self.project_id = self.config["CustomVision"]["ProjectId"]
            self.published_model_name = self.config["CustomVision"]["PublishedModelName"]
            self.confidence_threshold = float(self.config["CustomVision"]["ConfidenceThreshold"])
            
            # Inicializar cliente de Custom Vision para predicción
            prediction_credentials = ApiKeyCredentials(in_headers={"Prediction-key": self.prediction_key})
            self.prediction_client = CustomVisionPredictionClient(endpoint=self.prediction_endpoint, credentials=prediction_credentials)
            
            # Configuración de Azure SQL Database
            if "ConnectionStrings" in self.config and "CartoonNetwork_IAContext" in self.config["ConnectionStrings"]:
                self.sql_connection_string = self.config["ConnectionStrings"]["CartoonNetwork_IAContext"]
            else:
                # Si no existe en la configuración, construirla con los valores por defecto
                server = self.sql_server_var.get() if hasattr(self, 'sql_server_var') else "tcp:cartoonnetworkserver.database.windows.net"
                database = self.sql_database_var.get() if hasattr(self, 'sql_database_var') else "cartoonnetwork_db"
                username = self.sql_username_var.get() if hasattr(self, 'sql_username_var') else "servidor"
                password = self.sql_password_var.get() if hasattr(self, 'sql_password_var') else "Candy#1665"
                driver = self.sql_driver_var.get() if hasattr(self, 'sql_driver_var') else "ODBC Driver 18 for SQL Server"
                
                self.sql_connection_string = f"Driver={{{driver}}};Server={server};Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;"
            
            print("Servicios de Azure inicializados correctamente.")
            print(f"- Prediction Key: {self.prediction_key}")
            print(f"- Endpoint: {self.prediction_endpoint}")
            print(f"- Project ID: {self.project_id}")
            print(f"- Published Model Name: {self.published_model_name}")
            print(f"- Cadena de conexión SQL: {self.sql_connection_string}")
            
        except Exception as e:
            print(f"Error al inicializar servicios de Azure: {str(e)}")
            messagebox.showerror("Error", f"Error al inicializar servicios de Azure: {str(e)}")
    
    def browse_folder(self):
        folder_path = filedialog.askdirectory(title="Seleccionar Carpeta de Imágenes")
        if folder_path:
            self.selected_folder.set(folder_path)
            self.refresh_images_list()
    
    def refresh_images_list(self):
        folder_path = self.selected_folder.get()
        if not folder_path or not os.path.isdir(folder_path):
            messagebox.showwarning("Advertencia", "Por favor seleccione una carpeta válida.")
            return
        
        # Limpiar lista actual
        self.images_listbox.delete(0, tk.END)
        self.images_list = []
        
        # Buscar imágenes en la carpeta
        valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif')
        for filename in os.listdir(folder_path):
            if filename.lower().endswith(valid_extensions):
                full_path = os.path.join(folder_path, filename)
                self.images_list.append((filename, full_path))
                self.images_listbox.insert(tk.END, filename)
        
        if not self.images_list:
            messagebox.showinfo("Información", "No se encontraron imágenes en la carpeta seleccionada.")
        else:
            print(f"Se encontraron {len(self.images_list)} imágenes en la carpeta.")
    
    def clear_selection(self):
        self.images_listbox.selection_clear(0, tk.END)
    
    def clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete(1.0, tk.END)
        self.log_text.configure(state="disabled")
    
    def process_images_thread(self):
        # Verificar si hay imágenes seleccionadas
        selected_indices = self.images_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Advertencia", "Por favor seleccione al menos una imagen para procesar.")
            return
        
        # Obtener las imágenes seleccionadas
        selected_images = [self.images_list[i] for i in selected_indices]
        
        # Iniciar procesamiento en un hilo separado
        self.status_var.set("Procesando imágenes...")
        self.progress_var.set(0)
        
        # Deshabilitar botones durante el procesamiento
        for widget in self.root.winfo_children():
            if isinstance(widget, ttk.Button):
                widget.configure(state="disabled")
        
        # Iniciar hilo
        thread = threading.Thread(target=self.process_images, args=(selected_images,))
        thread.daemon = True
        thread.start()
    
    def process_images(self, selected_images):
        try:
            total_images = len(selected_images)
            processed = 0
            results = []
            
            print(f"Iniciando procesamiento de {total_images} imágenes...")
            
            for filename, file_path in selected_images:
                try:
                    # Actualizar progreso
                    self.progress_var.set((processed / total_images) * 100)
                    self.root.update_idletasks()
                    
                    # 1. Subir imagen a Azure Blob Storage
                    print(f"Subiendo imagen '{filename}' a Azure Blob Storage...")
                    
                    # Generar nombre único para el blob
                    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
                    blob_name = f"{timestamp}_{filename}"
                    
                    # Obtener cliente del contenedor
                    container_client = self.blob_service_client.get_container_client(self.container_name)
                    blob_client = container_client.get_blob_client(blob_name)
                    
                    # Subir la imagen
                    with open(file_path, "rb") as data:
                        blob_client.upload_blob(data, overwrite=True)
                    
                    # Guardar URL de la imagen
                    image_url = blob_client.url
                    print(f"Imagen subida como '{blob_name}'")
                    
                    # 2. Analizar con Custom Vision
                    print(f"Analizando imagen con Azure Custom Vision...")
                    
                    # Leer la imagen para análisis
                    with open(file_path, "rb") as image_file:
                        image_data = image_file.read()
                    
                    try:
                        # Analizar la imagen usando el cliente de predicción
                        print(f"Enviando imagen a Custom Vision: ProjectID={self.project_id}, ModelName={self.published_model_name}")
                        result = self.prediction_client.classify_image(
                            self.project_id,
                            self.published_model_name,
                            image_data
                        )
                        
                        # Procesar resultados
                        predictions = []
                        for prediction in result.predictions:
                            if prediction.probability >= self.confidence_threshold:
                                predictions.append({
                                    'tag': prediction.tag_name,
                                    'probability': prediction.probability
                                })
                        
                        # Ordenar predicciones
                        predictions.sort(key=lambda x: x['probability'], reverse=True)
                        
                        if predictions:
                            print(f"Predicción principal: {predictions[0]['tag']} ({predictions[0]['probability']:.2f})")
                        else:
                            print(f"No se encontraron predicciones por encima del umbral ({self.confidence_threshold})")
                        
                        # Guardar resultado
                        results.append({
                            'original_filename': filename,
                            'blob_name': blob_name,
                            'image_url': image_url,
                            'file_path': file_path,
                            'predictions': predictions
                        })
                    
                    except Exception as e:
                        print(f"Error al analizar la imagen con Custom Vision: {str(e)}")
                        # Intentar imprimir más detalles del error
                        import traceback
                        traceback.print_exc()
                        
                        # Guardar resultado con error
                        results.append({
                            'original_filename': filename,
                            'blob_name': blob_name,
                            'image_url': image_url,
                            'predictions': [],
                            'error': str(e)
                        })
                    
                    processed += 1
                    
                except Exception as e:
                    print(f"Error al procesar la imagen '{filename}': {str(e)}")
            
            # 3. Guardar resultados en la base de datos
            if results:
                print("Guardando resultados en Azure SQL Database...")
                try:
                    self.save_results_to_database(results)
                except Exception as e:
                    print(f"Error al guardar en la base de datos: {str(e)}")
                    # Intentar imprimir más detalles del error
                    import traceback
                    traceback.print_exc()
            
            # Actualizar progreso final
            self.progress_var.set(100)
            self.status_var.set(f"Procesamiento completado: {processed}/{total_images} imágenes")
            
            # Mostrar mensaje de finalización
            messagebox.showinfo("Procesamiento Completado", 
                               f"Se procesaron {processed} de {total_images} imágenes correctamente.")
            
            # Guardar resultados para consulta
            self.results = results
            
            # Cambiar a la pestaña de resultados y actualizar
            self.tab_control.select(1)  # Cambiar a la pestaña de resultados
            self.query_results_thread()
            
        except Exception as e:
            print(f"Error en el procesamiento: {str(e)}")
            messagebox.showerror("Error", f"Error en el procesamiento: {str(e)}")
            self.status_var.set("Error en el procesamiento")
        
        finally:
            # Habilitar botones
            for widget in self.root.winfo_children():
                if isinstance(widget, ttk.Button):
                    widget.configure(state="normal")
    
    def save_results_to_database(self, analysis_results):
        try:
            # Conectar a la base de datos
            print(f"Conectando a la base de datos con: {self.sql_connection_string}")
            conn = pyodbc.connect(self.sql_connection_string)
            cursor = conn.cursor()
            
            # Verificar si la tabla existe, si no, crearla
            cursor.execute("""
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ImageAnalysisResults')
            BEGIN
                CREATE TABLE ImageAnalysisResults (
                    Id INT IDENTITY(1,1) PRIMARY KEY,
                    OriginalFilename NVARCHAR(255),
                    BlobName NVARCHAR(255),
                    ImageUrl NVARCHAR(MAX),
                    TopTag NVARCHAR(100),
                    Confidence FLOAT,
                    AllPredictions NVARCHAR(MAX),
                    AnalysisDate DATETIME DEFAULT GETDATE()
                )
            END
            """)
            conn.commit()
            
            # Insertar resultados
            for result in analysis_results:
                original_filename = result['original_filename']
                blob_name = result['blob_name']
                image_url = result['image_url']
                
                # Obtener la predicción principal si existe
                if result['predictions']:
                    top_prediction = result['predictions'][0]
                    top_tag = top_prediction['tag']
                    confidence = top_prediction['probability']
                else:
                    top_tag = "Sin clasificación"
                    confidence = 0.0
                
                # Convertir todas las predicciones a formato string para almacenar
                all_predictions = str(result['predictions'])
                
                # Insertar en la base de datos
                cursor.execute("""
                INSERT INTO ImageAnalysisResults 
                (OriginalFilename, BlobName, ImageUrl, TopTag, Confidence, AllPredictions)
                VALUES (?, ?, ?, ?, ?, ?)
                """, (original_filename, blob_name, image_url, top_tag, confidence, all_predictions))
            
            conn.commit()
            print(f"Se guardaron {len(analysis_results)} resultados en la base de datos.")
            
            # Cerrar conexión
            cursor.close()
            conn.close()
            
            return True
            
        except Exception as e:
            print(f"Error al guardar en la base de datos: {str(e)}")
            return False
    
    def query_results_thread(self):
        # Iniciar consulta en un hilo separado
        self.status_var.set("Consultando resultados...")
        
        # Iniciar hilo
        thread = threading.Thread(target=self.query_results)
        thread.daemon = True
        thread.start()
    
    def query_results(self):
        try:
            # Obtener límite de resultados
            try:
                limit = int(self.limit_var.get())
            except:
                limit = 20
            
            # Limpiar tabla actual
            for item in self.results_tree.get_children():
                self.results_tree.delete(item)
            
            # Conectar a la base de datos
            print(f"Consultando resultados con: {self.sql_connection_string}")
            conn = pyodbc.connect(self.sql_connection_string)
            cursor = conn.cursor()
            
            # Consultar los resultados más recientes
            query = f"""
            SELECT TOP {limit} Id, OriginalFilename, BlobName, TopTag, Confidence, AnalysisDate, AllPredictions
            FROM ImageAnalysisResults
            ORDER BY AnalysisDate DESC
            """
            
            cursor.execute(query)
            rows = cursor.fetchall()
            
            # Guardar resultados completos para mostrar detalles
            self.db_results = []
            
            # Llenar la tabla
            for row in rows:
                id_val, filename, blob_name, tag, confidence, date, all_predictions = row
                
                # Formatear confianza como porcentaje
                confidence_str = f"{confidence:.1%}" if confidence else "N/A"
                
                # Formatear fecha
                date_str = date.strftime("%Y-%m-%d %H:%M:%S") if date else "N/A"
                
                # Insertar en la tabla
                self.results_tree.insert("", "end", values=(
                    id_val, filename, blob_name, tag, confidence_str, date_str
                ))
                
                # Guardar resultado completo
                self.db_results.append({
                    'id': id_val,
                    'filename': filename,
                    'blob_name': blob_name,
                    'tag': tag,
                    'confidence': confidence,
                    'date': date,
                    'all_predictions': all_predictions
                })
            
            # Cerrar conexión
            cursor.close()
            conn.close()
            
            # Actualizar estado
            self.status_var.set(f"Se encontraron {len(rows)} resultados")
            
        except Exception as e:
            print(f"Error al consultar resultados: {str(e)}")
            messagebox.showerror("Error", f"Error al consultar resultados: {str(e)}")
            self.status_var.set("Error al consultar resultados")
    
    def show_result_details(self, event):
        # Obtener el ítem seleccionado
        selected = self.results_tree.selection()
        if not selected:
            return
            
        item = selected[0]
        item_id = self.results_tree.item(item, "values")[0]
        
        # Buscar el resultado completo
        result = None
        for r in self.db_results:
            if str(r['id']) == str(item_id):
                result = r
                break
        
        if not result:
            return
        
        # Crear ventana de detalles
        details_window = tk.Toplevel(self.root)
        details_window.title(f"Detalles - {result['filename']}")
        details_window.geometry("800x600")
        details_window.minsize(400, 300)

        # Frame superior para imagen
        image_frame = ttk.Frame(details_window)
        image_frame.pack(pady=10, fill="both", expand=True)

        # Intentar cargar imagen
        image = None
        try:
            # Primero intentar desde ruta local (resultados recientes)
            if 'file_path' in result and os.path.exists(result['file_path']):
                image = Image.open(result['file_path'])
            else:
                # Si no existe, descargar desde Azure Blob Storage
                blob_client = self.blob_service_client.get_blob_client(
                    container=self.container_name,
                    blob=result['blob_name']
                )
                download_stream = blob_client.download_blob()
                image_data = download_stream.readall()
                image = Image.open(io.BytesIO(image_data))
                
            # Redimensionar y mostrar
            image.thumbnail((400, 400))
            photo = ImageTk.PhotoImage(image)
            img_label = ttk.Label(image_frame, image=photo)
            img_label.image = photo  # Mantener referencia
            img_label.pack()
        except Exception as e:
            ttk.Label(image_frame, text="Imagen no disponible", foreground="red").pack()
        
        # Contenido
        ttk.Label(details_window, text=f"Archivo: {result['filename']}", font=("", 12, "bold")).pack(pady=5)
        ttk.Label(details_window, text=f"ID: {result['id']}").pack(anchor="w", padx=10)
        ttk.Label(details_window, text=f"Blob: {result['blob_name']}").pack(anchor="w", padx=10)
        
        # Obtener el nombre del personaje a partir del tag
        tag = result['tag']
        character_name = personajes.get(tag, "Personaje desconocido")
        
        # Mostrar tanto el tag como el nombre del personaje
        ttk.Label(details_window, text=f"Etiqueta: {tag}", font=("", 10, "bold")).pack(anchor="w", padx=10)
        ttk.Label(details_window, text=f"Personaje: {character_name}", font=("", 10, "bold")).pack(anchor="w", padx=10)
        
        ttk.Label(details_window, text=f"Confianza: {result['confidence']:.1%}").pack(anchor="w", padx=10)
        ttk.Label(details_window, text=f"Fecha: {result['date'].strftime('%Y-%m-%d %H:%M:%S')}").pack(anchor="w", padx=10)
        
        # Mostrar todas las predicciones
        ttk.Label(details_window, text="Todas las predicciones:", font=("", 10, "bold")).pack(anchor="w", padx=10, pady=5)
        
        # Área de texto para predicciones
        predictions_text = ScrolledText(details_window, height=10, width=50)
        predictions_text.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Intentar parsear las predicciones
        try:
            # Las predicciones están almacenadas como string, intentar convertirlas a lista
            predictions_str = result['all_predictions']
            
            # Mostrar predicciones de manera legible
            if predictions_str and predictions_str != "[]":
                # Intentar evaluar el string como lista de diccionarios
                import ast
                predictions = ast.literal_eval(predictions_str)
                
                for i, pred in enumerate(predictions):
                    tag = pred.get('tag', 'Desconocido')
                    prob = pred.get('probability', 0)
                    # Obtener el nombre del personaje para cada predicción
                    character = personajes.get(tag, "Personaje desconocido")
                    predictions_text.insert(tk.END, f"{i+1}. {tag} ({character}): {prob:.1%}\n")
            else:
                predictions_text.insert(tk.END, "No hay predicciones disponibles.")
        except:
            predictions_text.insert(tk.END, "Error al parsear predicciones.\n")
            predictions_text.insert(tk.END, f"Datos originales: {result['all_predictions']}")
        
        predictions_text.configure(state="disabled")
        
        # Botón para cerrar
        ttk.Button(details_window, text="Cerrar", command=details_window.destroy).pack(pady=10)

def main():
    # Verificar argumentos
    if len(sys.argv) < 2:
        print("Uso: python cartoon_network_updated.py <ruta_config>")
        config_file = "config.json"  # Valor por defecto
    else:
        config_file = sys.argv[1]
    
    # Verificar que el archivo de configuración existe
    if not os.path.exists(config_file):
        print(f"Error: El archivo de configuración '{config_file}' no existe.")
        sys.exit(1)
    
    # Crear ventana principal
    root = tk.Tk()
    
    # Configurar estilo
    style = ttk.Style()
    if "clam" in style.theme_names():
        style.theme_use("clam")
    
    # Crear estilo para botón principal
    style.configure("Accent.TButton", font=("", 10, "bold"))
    
    # Iniciar aplicación
    app = CartoonNetworkApp(root, config_file)
    
    # Iniciar bucle principal
    root.mainloop()

if __name__ == "__main__":
    main()

