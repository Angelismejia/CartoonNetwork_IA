import pyodbc

server = 'tcp:cartoonnetworkserver.database.windows.net'
database = 'cartoonnetwork_db'
username = 'servidor'
password = 'Candy#1665'  # O la nueva contraseña que cambies
driver= '{ODBC Driver 18 for SQL Server}'

try:
    # Establecer la conexión
    conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};PORT=1433;DATABASE={database};UID={username};PWD={password};Encrypt=Mandatory;TrustServerCertificate=Yes;Connection Timeout=60')

    
    # Crear un cursor y hacer una consulta de prueba
    cursor = conn.cursor()
    cursor.execute("SELECT 1")  # Consulta sencilla para probar la conexión
    result = cursor.fetchone()
    
    # Si se obtiene un resultado, la conexión fue exitosa
    if result:
        print("Conexión exitosa a la base de datos!")
    else:
        print("La conexión fue establecida, pero no se obtuvo resultado.")
    
    # Cerrar la conexión
    conn.close()

except Exception as e:
    print(f"Error al conectar a la base de datos: {e}")
